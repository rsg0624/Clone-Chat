# E1 Avatar Thought → Action Simulator

This is a Phase-E1 cognitive lab to test how thoughts/messages
can be converted into avatar-driven actions using AI logic.

## Run locally
pip install -r requirements.txt
streamlit run app.py